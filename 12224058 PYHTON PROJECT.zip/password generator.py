import random
n=int(input("how many caracters required in password:"))
a=['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
A=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
N=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
s=["!","@","#","$","_","%","^","&","*",",",".","/"]
y=a+A+N+s
temp=random.choice(a)+random.choice(A)+random.choice(N)+random.choice(s)
g=random.choices(y,k=n-4)
temp_pas=""
for i in g:
    temp_pas+=i
password=temp+temp_pas
print(f"YOUR PASSWORD = {password}")








